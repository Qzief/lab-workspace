---
title: Pentingnya UI/UX Dalam Pengembangan Aplikasi
date: 2025-10-11
category: UI/UX
tags: [UI/UX, Praktikum]
author: Aruf
excerpt: Memberi pemahaman bagi mahasiswa dan pengembang tentang nilai strategis UI/UX, menjadi referensi untuk merancang aplikasi yang lebih ramah pengguna.
---

<iframe src="https://drive.google.com/file/d/1BGKUjJE2R1Ec0-DeHKHP6QoAEdDvCPn6/preview" width="640" height="480" allow="autoplay"></iframe>
